document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab");
  const sections = document.querySelectorAll(".tab-section");
  const btnScan = document.getElementById("check");
  const inputAddr = document.getElementById("address");
  const result = document.getElementById("result");
  const connectBtn = document.getElementById("connect-wallet");
  const walletStatus = document.getElementById("wallet-status");
  const recentList = document.getElementById("recent-list");

  // --- TAB SWITCHING ---
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      sections.forEach(s => s.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(tab.dataset.tab).classList.add("active");
    });
  });

  // --- SCAN BUTTON ---
  btnScan.addEventListener("click", async () => {
    const addr = inputAddr.value.trim();
    if (!addr) {
      result.innerText = "⚠️ Please enter a contract address";
      return;
    }

    result.innerText = "⏳ Scanning...";
    const score = await window.getTrustScore(addr);
    const scoreText =
      score >= 70
        ? `<span style='color:#0f0'>🏅 Safe | Score: ${score}</span>`
        : `<span style='color:#f33'>⚠️ Risky | Score: ${score}</span>`;
    result.innerHTML = scoreText;

    // save to recent
    const item = document.createElement("li");
    item.innerHTML = `${addr.substring(0, 10)}... → ${score}`;
    recentList.prepend(item);
  });

  // --- WALLET CONNECTION ---
  connectBtn.addEventListener("click", async () => {
    if (window.aptos) {
      try {
        const wallet = window.aptos; // Works for Petra or Martian
        const account = await wallet.connect();
        walletStatus.innerText = `✅ Connected: ${account.address.slice(0, 10)}...`;
      } catch (err) {
        walletStatus.innerText = "❌ Connection failed";
        console.error(err);
      }
    } else {
      walletStatus.innerText = "⚠️ No Aptos wallet detected";
    }
  });

  // --- SETTINGS ---
  const autoDetect = document.getElementById("auto-detect");
  autoDetect.addEventListener("change", () => {
    chrome.storage.sync.set({ autoDetect: autoDetect.checked });
  });
  chrome.storage.sync.get("autoDetect", data => {
    autoDetect.checked = data.autoDetect || false;
  });
});
