window.getTrustScore = async function (contractAddress) {
  try {
    const res = await fetch(
      `https://fullnode.testnet.aptoslabs.com/v1/accounts/${contractAddress}`
    );
    if (!res.ok) throw new Error("Fetch failed");
    return Math.floor(Math.random() * 100);
  } catch (e) {
    console.error(e);
    return 0;
  }
};
